experiment.m is used to conduct the simulations on conjugate vs independent priors

In rand_gibbs_sep2021.m, one can choose 'conjugate' or 'independent' 